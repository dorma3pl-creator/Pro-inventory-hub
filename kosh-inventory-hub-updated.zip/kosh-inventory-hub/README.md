# Kosh Inventory Hub

A responsive, static warehouse inventory dashboard for GitHub Pages, including stock-in/stock-out trends and a pending-putaway list for received items not yet assigned to a bin/location.

## Publish with GitHub Pages
1. Sign in to GitHub and create a new **public** repository named `kosh-inventory-hub`.
2. Upload `index.html` to the repository root and commit the change.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`, then click **Save**.
6. Wait for GitHub Pages to publish the site. Your URL will look like:
   `https://YOUR-USERNAME.github.io/kosh-inventory-hub/`

## Important
This is a front-end demo with sample figures and sample warehouse records. It does not connect to Kosh Pro or any live database. Replace the demo values or add a secure backend/API integration before using it for operational reporting. Never put API keys or passwords in front-end code.
